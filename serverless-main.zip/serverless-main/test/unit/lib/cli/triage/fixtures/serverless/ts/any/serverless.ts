module.exports = {
  foo: { component: 'foo' },
}

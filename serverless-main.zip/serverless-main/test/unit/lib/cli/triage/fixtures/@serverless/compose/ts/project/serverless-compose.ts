module.exports = {
  name: 'serverless-compose-example',
  services: {
    resources: {
      path: 'resources',
    },
  },
}

'use strict'

module.exports = {
  service: 'js-service',
  provider: 'js-provider',
  configValidationMode: 'error',
  frameworkVersion: '*',
}

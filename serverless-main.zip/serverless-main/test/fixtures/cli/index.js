'use strict'

module.exports = require('@serverless/test/setup-fixtures-engine')(__dirname)

'use strict'

module.exports.layer = (foo, bar) => {
  return foo + bar
}

'use strict'

module.exports = class CustomPlugin {}

'use strict'

module.exports = function SomePlugin() {}

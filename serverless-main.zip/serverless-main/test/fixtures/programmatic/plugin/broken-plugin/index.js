'use strict'

throw new Error('failed to load plugin')

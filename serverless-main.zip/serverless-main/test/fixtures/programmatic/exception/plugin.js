'use strict'

module.exports = class Plugin {
  constructor() {
    throw new Error('Stop')
  }
}

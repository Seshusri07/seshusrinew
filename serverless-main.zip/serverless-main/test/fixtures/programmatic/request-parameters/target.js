'use strict'

module.exports.handler = () => {
  return {
    statusCode: 200,
    body: 'OK',
  }
}

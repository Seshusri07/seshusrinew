def handler(event:, context:)
  {"deadlineMs" => context.deadline_ms}
end


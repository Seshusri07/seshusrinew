'use strict'

module.exports = { dataInputKey: 'dataInputValue' }

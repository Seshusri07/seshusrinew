'use strict'

throw new Error('Initialization failure')

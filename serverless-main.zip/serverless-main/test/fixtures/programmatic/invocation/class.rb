module MyModule
  class MyClass
    def self.my_class_method(event:, context:)
      {"source" => "rubyclass"}
    end
  end
end

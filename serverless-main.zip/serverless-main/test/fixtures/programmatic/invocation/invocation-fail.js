'use strict'

module.exports.handler = () => {
  throw new Error('Invocation fail')
}

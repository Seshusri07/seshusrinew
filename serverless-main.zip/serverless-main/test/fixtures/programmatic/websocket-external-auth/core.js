'use strict'

exports.minimal = async function minimal() {
  return { statusCode: 200 }
}

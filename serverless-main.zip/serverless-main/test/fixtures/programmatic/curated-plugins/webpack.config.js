'use strict'

module.exports = { entry: './index.js', target: 'node', mode: 'production' }

module.exports = {
    extends: ['../standards/src/eslint.cjs'],
}
  
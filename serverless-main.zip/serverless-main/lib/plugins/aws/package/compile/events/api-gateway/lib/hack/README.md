# Hack

This directory contains code which performs raw SDK calls rather than going through CloudFormation template compilations.

We're planning to port the logic of these code snippets to raw CloudFormation once AWS fixes the problems currently preventing us from solely relying on CloudFormation.
